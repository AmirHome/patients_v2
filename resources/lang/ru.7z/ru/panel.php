<?php

return [
    'site_title' => 'Администратор',

];
