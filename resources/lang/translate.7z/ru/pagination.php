<?php

return [
'previous' => '&laquo; Назад',
'next'     => 'Вперед &raquo;',

];
