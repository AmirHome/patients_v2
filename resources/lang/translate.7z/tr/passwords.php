<?php

return [
    'password' => 'Parola en az 6 karakterli olmalı ve onay alanıyla aynı olmalı',
    'reset'    => 'Parolanız  yenilendi!',
    'sent'     => 'E-posta adresinize parola yenileme postası gönderildi!',
    'token'    => 'Parola yenileme kodu geçersiz.',
    'user'     => 'Bu e-posta adresiyle bir hesap bulamadık.',
    'updated'  => 'Parolanız değiştirildi!',

];
